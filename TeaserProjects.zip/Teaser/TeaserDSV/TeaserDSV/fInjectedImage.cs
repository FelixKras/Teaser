﻿using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.ComponentModel;
using System.Configuration;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Linq;
using System.Text;
using System.Threading;
using System.Timers;
using System.Windows.Forms;
using TeaserDSV.Engines;
using TeaserDSV.Model;
using TeaserDSV.Utilities;
using ThreadState = System.Threading.ThreadState;
using Timer = System.Timers.Timer;

namespace TeaserDSV
{
    public partial class fInjectedImage : Form
    {
        #region Private Members
        private Listener oListener;
        private ConcurrentQueue<SixMsg> conqSixMsgs;

        private Thread thrTargetDraw;
        private Thread thrSixDataHandle;
        private readonly cSmoker oSmoker = new cSmoker();
        private int cParticleNumber;
        private PointF emitterOfSmokeLocation;
        private readonly object _lockObj = new object();
        private readonly AutoResetEvent areDraw = new AutoResetEvent(false);

        //private PointF[] pntTargetShapeOrig;
        //private PointF[] pntTargetShapeTransformed;
        private bool bIsRunning { get; set; }
        private bool bThreadStopped { get; set; }
        private Action actRefresh;

        private Brush particleBrush;

        private Graphics grphxDrawer;
        private Image bgImage;
        private int iFrameNum = 0;

        private bool mouseDown;
        private Point lastFormLocation;
        private Body m_body;
        private CPUReference m_engine;
        private bool IsLedOn;
        private int m_color;
        private int m_direction;
        private Timer recalcTimer;

        private Bitmap ledImage = new Bitmap(@"O:\3184\Felix\Projects\Teaser\TeaserDSV\External\OnSep32x32_.png");
        #endregion Private Members


        public fInjectedImage()
        {
            InitializeComponent();
            SmokeColorInit();

        }
        protected override void OnLoad(EventArgs e)
        {
            base.OnLoad(e);
            InitializePicBox();
            InitializeTimer();
            InitTarget();
            StartListening();
            InitSixDataHandler();
        }
        private void RefreshPicBox()
        {
            picBox.Invalidate();
            RedrawScene();
            picBox.Update();
        }
        private void InitializePicBox()
        {
            picBox.Dock = DockStyle.Fill;
            bgImage = Image.FromFile(@"..\Images\bg2.jpg");
            picBox.Image = bgImage;
            Screen[] screens = Screen.AllScreens;
            this.Location = screens[1].WorkingArea.Location;
            actRefresh = new Action(RefreshPicBox);
            this.FormBorderStyle = FormBorderStyle.None;
            this.WindowState = FormWindowState.Maximized;

        }

        private void SmokeColorInit()
        {
            Color tmp = Color.Black;
            tmp = Color.FromName(ConfigurationManager.AppSettings["SmokeColor"]);
            if (tmp.IsNamedColor)
            {
                if (tmp != Color.White && tmp != Color.Black)
                {
                    MessageBox.Show("Invalid smoke color");
                    return;
                }

                if (tmp == Color.White)
                {
                    m_color = 255;
                    m_direction = -1;
                }
                else
                {
                    m_color = 0;
                    m_direction = 1;
                }
            }
            else
            {
                MessageBox.Show("Invalid smoke color");
                return;
            }
        }

        private void InitSixDataHandler()
        {
            thrSixDataHandle = new Thread(HandleMessages) { IsBackground = true, Name = "Six handler" };
            thrSixDataHandle.Start();

        }

        private void InitializeTimer()
        {
            recalcTimer = new System.Timers.Timer(SettingsHolder.Instance.RedrawFreq);
            recalcTimer.Elapsed += RecalcTimer_Elapsed;
            recalcTimer.Enabled = true;
        }
        private void InitTarget()
        {
            cParticleNumber = SettingsHolder.Instance.ParticleNumber;
            conqSixMsgs = new ConcurrentQueue<SixMsg>();
            bIsRunning = true;
            bThreadStopped = false;
            thrTargetDraw = new Thread(SmokeParticlesManager) { IsBackground = true, Name = "Smoke particle thread" };
            thrTargetDraw.Start();


            //pntTargetShapeOrig = new PointF[]
            //{

            //    //new PointF(1.00F, -6.00F),
            //    //new PointF(0F, -3.50F),
            //    //new PointF(-4.5F,   2.0F),
            //    //new PointF(-6.0F,   6.5F),
            //    //new PointF(-2.0F,   4.5F),
            //    //new PointF(3.00F, -0.50F),
            //    //new PointF(5.50F, -1.50F),
            //    //new PointF(1.00F, -6.00F)

            //    new PointF(2.00F, -12.00F),
            //    new PointF(0F, -7.0F),
            //    new PointF(-9.0F,   4.0F),
            //    new PointF(-12.0F,   13.0F),
            //    new PointF(-4.0F,   9.0F),
            //    new PointF(6.00F, -1.0F),
            //    new PointF(11.00F, -3.00F),
            //    new PointF(2.00F, -12.00F),
            //    new PointF(-6.5F, 6.5F),
            //    new PointF(6.5F, -7.5F),
            //    new PointF(3F, -4F)

            // };
            //pntTargetShapeTransformed = pntTargetShapeOrig;

            m_engine = new CPUReference();
            List<BodyPoint> temporaryPoints = new List<BodyPoint>();
            m_body = new Body
            {
                CenterOfMassSpherical = new double[]
                {
                    1,90,90//CenterOfMassR,CenterOfMassTheta,CenterOfMassPhi
                }
            };


            // Add point to list.
            //Plane 1 
            temporaryPoints.Add(new BodyPoint { Position = new double[] { 2, -12, 1 }, IsLed = false });
            temporaryPoints.Add(new BodyPoint { Position = new double[] { 0, -7, 1 }, IsLed = false });
            temporaryPoints.Add(new BodyPoint { Position = new double[] { -9, 4, 1 }, IsLed = false });
            temporaryPoints.Add(new BodyPoint { Position = new double[] { -12, 13, 1 }, IsLed = false });
            temporaryPoints.Add(new BodyPoint { Position = new double[] { -4, 9, 1 }, IsLed = false });
            temporaryPoints.Add(new BodyPoint { Position = new double[] { 6, -1, 1 }, IsLed = false });
            temporaryPoints.Add(new BodyPoint { Position = new double[] { 11, -3, 1 }, IsLed = false });
            temporaryPoints.Add(new BodyPoint { Position = new double[] { 2, -12, 1 }, IsLed = false });
            //temporaryPoints.Add(new BodyPoint { Position = new double[] { -6.5, 6.5, 5 }, IsLed = false });
            //temporaryPoints.Add(new BodyPoint { Position = new double[] { 6.5, -7.5, 5 }, IsLed = false });
            //temporaryPoints.Add(new BodyPoint { Position = new double[] { 3, -4, 5 }, IsLed = false });
            //temporaryPoints.Add(new BodyPoint { Position = new double[] { -6.5, 6.5, -5 }, IsLed = false });
            temporaryPoints.Add(new BodyPoint { Position = new double[] { 6.5, -7.5, -5 }, IsLed = true });
            //temporaryPoints.Add(new BodyPoint { Position = new double[] { 3, -4, -5 }, IsLed = false });

            //Plane2 
            //temporaryPoints.Add(new BodyPoint { Position = new double[] { 0, 12, 1 }, IsLed = false });
            //temporaryPoints.Add(new BodyPoint { Position = new double[] { -6, 8, 1 }, IsLed = false });
            //temporaryPoints.Add(new BodyPoint { Position = new double[] { -6, 4, 1 }, IsLed = false });
            //temporaryPoints.Add(new BodyPoint { Position = new double[] { -12, -12, 1 }, IsLed = false });
            //temporaryPoints.Add(new BodyPoint { Position = new double[] { 0, -12, 1 }, IsLed = true});
            //temporaryPoints.Add(new BodyPoint { Position = new double[] { 12, -12, 1 }, IsLed = false });
            //temporaryPoints.Add(new BodyPoint { Position = new double[] { 6, 4, 1 }, IsLed = false });
            //temporaryPoints.Add(new BodyPoint { Position = new double[] { 6, 8, 1 }, IsLed = false });

            //temporaryPoints.Add(new BodyPoint { Position = new double[] { -6, 8, 5 }, IsLed = false });
            //temporaryPoints.Add(new BodyPoint { Position = new double[] { -6, 4, 5 }, IsLed = false });
            //temporaryPoints.Add(new BodyPoint { Position = new double[] { -12, -12, 5 }, IsLed = false });
            //temporaryPoints.Add(new BodyPoint { Position = new double[] { 12, -12, 5 }, IsLed = false });
            //temporaryPoints.Add(new BodyPoint { Position = new double[] { 6, 4, 5 }, IsLed = false });
            //temporaryPoints.Add(new BodyPoint { Position = new double[] { 6, 8, 5 }, IsLed = false });


            // Store points in body.
            m_body.OriginalPoints = temporaryPoints.ToArray();
        }
        private void RecalcTimer_Elapsed(object sender, ElapsedEventArgs e)
        {
            areDraw.Set();
        }

        public void SmokeParticlesManager()
        {

            try
            {
                while (bIsRunning)
                {
                    areDraw.WaitOne();

                    lock (_lockObj)
                    {
                        for (int ii = oSmoker.Particles.Count - 1; ii >= 0; ii--)
                        {
                            if (oSmoker.Particles[ii].PerformFrame())
                            {
                                oSmoker.ReturnToPool(oSmoker.Particles[ii]);
                            }
                            if (!bIsRunning)
                            {
                                break;
                            }

                        }

                    }
                    if (bIsRunning)
                    {
                        this.Invoke(actRefresh);
                    }

                }


            }
            catch (ThreadAbortException ex)
            {
                Debug.Print("Proc Thread aborting");

            }
            this.Invoke(new MethodInvoker(CloseThisForm));
        }
        private void CreateParticleEmitter(PointF emitPoint)
        {

            lock (_lockObj)
            {
                for (int ii = 0; ii < cParticleNumber; ii++)
                {
                    Particle createparticle = oSmoker.GetFromPool(emitPoint, SettingsHolder.Instance.ParticlesSpeed);
                    oSmoker.Particles.Add(createparticle);
                }
            }
        }

        private void RedrawScene()
        {
            Stopwatch sw = Stopwatch.StartNew();
            Image copyBGImage = bgImage.DeepClone();
            grphxDrawer = Graphics.FromImage(copyBGImage);


            RedrawParticles(grphxDrawer);


            RedrawTarget(grphxDrawer, IsLedOn);
            picBox.Image = copyBGImage.DeepClone();


            //m_BlinkingLed = DateTime.Now.Second % 2 == 0 ? Color.Red : Color.White;
            //copyBGImage.Save(string.Format("Image{0:D8}.jpg", iFrameNum++));

            sw.Stop();
            double result = ((double)sw.ElapsedTicks / Stopwatch.Frequency * 1000F);

        }

        private void RedrawTarget(Graphics grphxDrawerTarget, bool IsLedVisible = false)
        {
            if (m_body.OriginalPointsFloat != null)
            {
                grphxDrawerTarget.FillPolygon(new SolidBrush(Color.DarkSlateGray), m_body.OriginalPointsFloat);

                for (int i = 0; i < m_body.OriginalPoints.Length; i++)
                {
                    if (m_body.OriginalPoints[i].IsLed && IsLedVisible)
                    {
                        DrawLedFromFile(grphxDrawerTarget, m_body.OriginalPointsFloat[i], m_body.OriginalPoints[i].Position);

                        //Rectangle circle = new Rectangle(new Point((int)m_body.OriginalPointsFloat[i].X - 5,(int)m_body.OriginalPointsFloat[i].Y - 5), new Size(10, 10));
                        //grphxDrawerTarget.FillEllipse(new SolidBrush(m_BlinkingLed), circle);

                    }
                }
            }
        }

        private void DrawLedFromFile(Graphics grphxDrawerTarget, PointF positionOnScreen, double[] positionIn3D)
        {

            ledImage.MakeTransparent(Color.Black);
            float ApparentAngle = cCalcer.CameraSettings.LedSize / (float)positionIn3D.Norm();
            float FOVAngle = (float)(cCalcer.CameraSettings.FOVangAz * cCalcer.CameraSettings.Deg2Rad);
            float PixelsOnFPA = FOVAngle / ApparentAngle / cCalcer.CameraSettings.SensorWidth;

            float w = ledImage.Width;//*fScale;
            float h = ledImage.Height;//*fScale;
            Point leftUp = new Point((int)(positionOnScreen.X - w / 2), (int)(positionOnScreen.Y - h / 2));

            Rectangle destRect = new Rectangle(leftUp.X, leftUp.Y, (int)w, (int)h);

            grphxDrawerTarget.DrawImage(ledImage, destRect, new Rectangle(0, 0, (int)w, (int)h), GraphicsUnit.Pixel);
        }

        private void RedrawParticles(Graphics grphxDrawerParticles)
        {

            int alpha = 0;

            lock (_lockObj)
            {
                foreach (Particle p in oSmoker.Particles)
                {
                    p.GetColorToLife(ref alpha, ref m_color, m_direction);

                    using (particleBrush = new SolidBrush(Color.FromArgb(alpha, m_color, m_color, m_color)))
                    {
                        grphxDrawerParticles.FillEllipse(particleBrush,
                            p.Location.X - SettingsHolder.Instance.ParticleSize / 2,
                            p.Location.Y - SettingsHolder.Instance.ParticleSize / 2,
                            SettingsHolder.Instance.ParticleSize, SettingsHolder.Instance.ParticleSize);
                    }

                }
            }
        }


        private void StartListening()
        {
            oListener = new Listener(SettingsHolder.Instance.ipAddress, int.Parse(SettingsHolder.Instance.port));
            oListener.StartListening();
            oListener.evCommandReceived += OnMessageReceived;

        }

        private void OnMessageReceived(object sender, EventArgs eventArgs)
        {
            SixMsg oSixMsg = (SixMsg)sender;
            conqSixMsgs.Enqueue(oSixMsg);

        }
        private void HandleMessages()
        {
            SixMsg oSixMsg;
            while (bIsRunning)
            {
                try
                {
                    if (conqSixMsgs.Count > 0)
                    {
                        conqSixMsgs.TryDequeue(out oSixMsg);
                        emitterOfSmokeLocation = cCalcer.ObjectToCameraProjection(oSixMsg);
                        emitterOfSmokeLocation.X = picBox.Width * emitterOfSmokeLocation.X / cCalcer.CameraSettings.SensorWidth;
                        emitterOfSmokeLocation.Y = picBox.Height * emitterOfSmokeLocation.Y / cCalcer.CameraSettings.SensorHeight;

                        m_body.RollAngle = oSixMsg.Object_Roll;
                        m_body.AspectAngle = 180 - oSixMsg.Object_Yaw;
                        m_body.RotateAngle = oSixMsg.Object_Pitch;
                        m_body.Distance = 1;
                        m_engine.ComputeProjection(m_body);
                        //pntTargetShapeTransformed = cCalcer.ObjectToCameraProjection(pntTargetShapeOrig, oSixMsg);

                        m_body.OriginalPointsFloat = m_body.OriginalPoints.ToFloatPointArray();



                        m_body.OriginalPointsFloat = cCalcer.ObjectToCameraProjection(m_body.OriginalPointsFloat);
                        m_body.OriginalPointsFloat = ShiftToCM(m_body.OriginalPointsFloat, emitterOfSmokeLocation);

                        m_engine.RestoreOriginalCenterOfMassAndPointsPosition(m_body, m_engine.originalCoM, m_engine.originalPointsPosition);
                        IsLedOn = (oSixMsg.Object_model == 1);
                        //BoundaryDetect();
                        if (oSixMsg.Smoke == 1)
                        {
                            CreateParticleEmitter(emitterOfSmokeLocation);
                        }


                    }
                    else
                    {
                        continue;
                    }
                }
                catch (Exception e)
                {
                    Console.WriteLine(e);
                    throw;
                }

            }
        }

        private PointF[] ShiftToCM(PointF[] pntTargetShapeTransformed, PointF cmEmitterOfSmokeLocation)
        {
            PointF[] result = new PointF[pntTargetShapeTransformed.Length];
            for (int ii = 0; ii < pntTargetShapeTransformed.Length; ii++)
            {
                result[ii].X += pntTargetShapeTransformed[ii].X + cmEmitterOfSmokeLocation.X;
                result[ii].Y += pntTargetShapeTransformed[ii].Y + cmEmitterOfSmokeLocation.Y;
            }
            return result;
        }


        private void CloseThisForm()
        {
            oListener.StopListening();
            recalcTimer.Stop();
            bIsRunning = false;
            this.Close();
        }
#warning For debug
        private void BoundaryDetect()
        {
            if (emitterOfSmokeLocation.X > picBox.Width)
            {
            }
            else if (emitterOfSmokeLocation.Y > picBox.Height)
            {
            }
            else if (emitterOfSmokeLocation.X < 0)
            {
            }
            else if (emitterOfSmokeLocation.Y < 0)
            {
            }
        }

        #region From event handlers

        protected override void OnClosing(CancelEventArgs e)
        {
            bIsRunning = false;
            if (thrTargetDraw.IsAlive)
            {
                thrTargetDraw.Abort();
            }

            base.OnClosing(e);
        }

        private void _MouseDoubleClick(object sender, MouseEventArgs e)
        {
            bIsRunning = false;
        }

        private void _DoubleClick(object sender, EventArgs e)
        {
            bIsRunning = false;

        }

        private void frmMain_MouseDown(object sender, MouseEventArgs e)
        {
            mouseDown = true;
            lastFormLocation = e.Location;
        }

        private void frmMain_MouseMove(object sender, MouseEventArgs e)
        {
            if (mouseDown)
            {
                this.Location = new Point(
                    (this.Location.X - lastFormLocation.X) + e.X, (this.Location.Y - lastFormLocation.Y) + e.Y);

                this.Update();
            }
        }

        private void frmMain_MouseUp(object sender, MouseEventArgs e)
        {
            mouseDown = false;
        }
        #endregion From event handlers


    }
}
