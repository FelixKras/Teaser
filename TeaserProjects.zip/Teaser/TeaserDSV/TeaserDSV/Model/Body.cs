﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TeaserDSV.Model
{
    /// <summary>
    /// Represents a complete body with additional functionality.
    /// 
    /// A body is composed of points (as a point cloud for example).
    /// </summary>
    public class Body
    {
        #region Input Parameters
        /// <summary>
        /// Array of original points that describe face edges of the object.
        /// Also can be thought of as a wireframe representation.
        /// </summary>
        public BodyPoint[] OriginalPoints { get; set; }
        public PointF[] OriginalPointsFloat { get; set; }
        
        
        /// <summary>
        /// Distance of object from camera, in meters.
        /// </summary>
        public double Distance { get; set; }
        /// <summary>
        /// Aspect angle is defined between the camera LoS (Line-of-Sight) to 
        /// the object and the object's heading direction (body vector).
        /// The angle is defined as an extrinsic parameter, in the camera frame.
        /// 
        /// - First compute the vector of the object relative to the camera, 
        ///   this is the Line-of-Sight (LoS).
        /// - Then, in the body frame, rotate the object around the Z axis by
        ///   the aspect angle, counter-clockwise.
        /// </summary>
        public double AspectAngle { get; set; }
        /// <summary>
        /// Roll angle is defined along the body vector as above.
        /// This is an intrinsic parameter, in the body frame.
        /// </summary>
        public double RollAngle { get; set; }
        /// <summary>
        /// Rotate angle is defined as the azimuth (yaw), measured with 
        /// respect to a vector emerging from CoG and perpendicular to the 
        /// body vector.
        /// This is an intrinsic parameter, in the body frame.
        /// </summary>
        public double RotateAngle { get; set; }

        /// <summary>
        /// 3D vector containing body center-of-mass (CoM) expressed in 
        /// spherical coordinates.
        /// </summary>
        public double[] CenterOfMassSpherical { get; set; }

        /// <summary>
        /// Specifies the desired signal strength of the projected body.
        /// </summary>
        public double TotalSignalStrength { get; set; }
        #endregion

        #region Computed Parameters
        /// <summary>
        /// 3D vector containing body center-of-mass (CoM) expressed in 
        /// cartesian coordinates.
        /// </summary>
        public double[] CenterOfMassCartesian { get; set; }

        /// <summary>
        /// Array of 3D vector per body point of the relative vector between
        /// the original point and the body center-of-mass (this way 
        /// translations and rotations are much simpler to express).
        /// </summary>
        public double[][] RelativePointsPositionToCenterOfMass { get; set; }

        /// <summary>
        /// 3D vector containing the body vector (its "line-of-sight"/heading direction).
        /// </summary>
        public double[] BodyVector { get; set; }

        /// <summary>
        /// Array of Z-depth value per body point along a specific camera 
        /// line-of-sight.
        /// </summary>
        public double[] PointsDepthAlongLineOfSight { get; set; }

        /// <summary>
        /// Array of 2D vector per body point that contains the projected point
        /// coordinates in specific camera plane.
        /// </summary>
        public double[][] ProjectedPointsInWorldCoordinates { get; set; }

        /// <summary>
        /// Array of 2D vector per body point that contains the scaled projected
        /// point coordinates in specific camera plane including sub-pixel offset.
        /// </summary>
        public double[][] ProjectedPointsInFullSensorPixelCoordinates { get; set; }

        /// <summary>
        /// Array of 2D vector per body point that contains the sub-pixel offset
        /// value for projected coordinates (for PSF patch contribution).
        /// </summary>
        public double[][] ProjectedPointsPixelOffset { get; set; }

        /// <summary>
        /// Array with 2D array per body point that contains the integer pixel 
        /// coordinates of the point after projection.
        /// </summary>
        public int[][] ProjectedPointsInSensorPixelCoordinates { get; set; }

        /// <summary>
        /// Stores for every pixel in image/sensor the face index
        /// containing the point that was projected on that pixel,
        /// and is closest to.
        /// </summary>
        public int[,] SortedPointsFaceIDPerPixel { get; set; }
        /// <summary>
        /// Stores for every pixel in image/sensor the point index
        /// in the relevant face, that belong to that pixel and is closest to.
        /// </summary>
        public int[,][] SortedPointsFaceCoordsPerPixel { get; set; }
        /// <summary>
        /// Contains the distance of the closest point for each pixel.
        /// </summary>
        public double[,] SortedPointsPerPixelDistance { get; set; }

        /// <summary>
        /// Contains the number of points that hit a specific pixel in sensor 
        /// coordinates.
        /// </summary>
        public int[,] ImageHitCount { get; set; }

        /// <summary>
        /// Contains the final pixel value in full precision.
        /// </summary>
        public double[,] FinalImageFull { get; set; }

        /// <summary>
        /// Contains the final pixel value in integer units.
        /// </summary>
        public ushort[,] FinalImage { get; set; }
        #endregion
    }
}
