﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TeaserDSV.Model;
using TeaserDSV.Utilities;

namespace TeaserDSV.Engines
{
    public class CPUReference
    {
        //// <summary>
        //// Constructor for processing engine, the provided camera is used for
        //// consequent projections.
        //// </summary>
        //// <param name="camera">Camera instance to use for projections.</param>
        //public CPUReference(Camera camera)
        //{
        //    this.camera = camera;

        //    // Compute camera projection axes.
        //    BLAS.Normalize(camera.LineOfSightCartesian);
        //    ComputeProjectionAxes(this.camera);
        //}
        double[] m_CameraPosition = new double[] { 0, 0, 0 };
        double[] m_CameraLOS = new double[] { 1, 0, 0 };
        public double[] originalCoM;
        public List<double[]> originalPointsPosition;
        public void ComputeProjection(Body body)
        {
            // Compute cartesian body CoM based on spherical coordinates.

            ComputeCartesianCenterOfMass(body);

            // Store original body CoM (and points dataset) to restore at the 

            originalCoM = new double[body.CenterOfMassCartesian.Length];
            originalPointsPosition = new List<double[]>();
            CopyOriginalCenterOfMassAndPointsPosition(body, originalCoM, originalPointsPosition);

            // Compute relative position of each body point with respect to CoM.
            ComputeRelativePointsPositionToCenterOfMass(body);

            // Translate CoM by required distance from camera location.
            TranslateCenterOfMassByDistance(body);

            // Compute body vector.
            ComputeBodyVector(body);

            // Rotate body points around Z axis using aspect angle.
            TransformBodyPointsByYaw(body);

            // Rotate body points around body-vector using roll angle.
            TransformBodyPointsByRoll(body);

            // Rotate body points around LoS using rotate angle.
            TransformBodyPointsByRotate(body);

        }


        /// <summary>
        /// Computes cartesian center-of-mass for body using given spherical 
        /// coordinates.
        /// Final position is relative to camera position.
        /// </summary>
        /// <param name="body">Body instance to convert center-of-mass 
        /// coordinates from spherical to cartesian.</param>
        private void ComputeCartesianCenterOfMass(Body body)
        {
            double r = body.CenterOfMassSpherical[0];
            double theta = body.CenterOfMassSpherical[1];
            double phi = body.CenterOfMassSpherical[2];

            // Convert from spherical to cartesian coordinates.
            body.CenterOfMassCartesian = new double[]
            {
                // X = Body.R * sin(body.Theta) * sin(body.Phi)
                r * Math.Sin(Rotations.ToRadians(theta)) * Math.Sin(Rotations.ToRadians(phi)),
                // Y = Body.R * sin(body.Theta) * cos(body.Phi)
                r * Math.Sin(Rotations.ToRadians(theta)) * Math.Cos(Rotations.ToRadians(phi)),
                // Z = Body.R * cos(body.Theta)
                r * Math.Cos(Rotations.ToRadians(theta))
            };

            // Distance of body is relative to camera position.
            body.CenterOfMassCartesian = BLAS.Add(body.CenterOfMassCartesian, m_CameraPosition);
        }

        /// <summary>
        /// Copies center-of-mass and points position from body instance to 
        /// given arrays so they can be restored later.
        /// </summary>
        /// <param name="body">Body instance to copy center-of-mass and points position from.</param>
        /// <param name="copyOfCoM">Array to copy body center-of-mass into.</param>
        /// <param name="copyOfPoints">List to copy body points position into.</param>
        private void CopyOriginalCenterOfMassAndPointsPosition(Body body, double[] copyOfCoM, List<double[]> copyOfPoints)
        {
            // Copy CoM from body into given array.
            Array.Copy(body.CenterOfMassCartesian, copyOfCoM, copyOfCoM.Length);

            // Copy points from body into given list.
            foreach (var point in body.OriginalPoints)
            {
                double[] originalPosition = new double[point.Position.Length];
                Array.Copy(point.Position, originalPosition, point.Position.Length);

                copyOfPoints.Add(originalPosition);
            }
        }

        /// <summary>
        /// Computes the relative position between each body point and the current 
        /// center-of-mass.
        /// </summary>
        /// <param name="body">Body to compute relative positions for.</param>
        private void ComputeRelativePointsPositionToCenterOfMass(Body body)
        {
            // Initialize relative position array.
            body.RelativePointsPositionToCenterOfMass = new double[body.OriginalPoints.Length][];

            // Loop over all body points and compute relative position with respect to CoM.
            for (int i = 0; i < body.OriginalPoints.Length; i++)
            {
                body.RelativePointsPositionToCenterOfMass[i] =
                    BLAS.Subtract(body.OriginalPoints[i].Position, body.CenterOfMassCartesian);
            }
        }

        /// <summary>
        /// Translate body center-of-mass so its distance from the camera is at desired distance.
        /// </summary>
        /// <param name="body">Body to translate.</param>
        private void TranslateCenterOfMassByDistance(Body body)
        {
            //double currentDistance = BLAS.Norm2(BLAS.Subtract(body.CenterOfMassCartesian, camera.Position));
            double currentDistance = BLAS.Norm2(BLAS.Subtract(body.CenterOfMassCartesian, m_CameraPosition));
            double distanceRatio = body.Distance / currentDistance;

            //Trace.TraceInformation("Current distance: {0}", currentDistance);
            //Trace.TraceInformation("Distance ratio: {0}", distanceRatio);

            body.CenterOfMassCartesian = BLAS.PointwiseMultiply(body.CenterOfMassCartesian, distanceRatio);

            // Update body points position with respect to new CoM.
            UpdatePointsPositionWithCenterOfMass(body);
        }

        /// <summary>
        /// Update points position with respect to center-of-mass, using 
        /// previously computed relative position.
        /// </summary>
        /// <param name="body">Body to update its points.</param>
        private void UpdatePointsPositionWithCenterOfMass(Body body)
        {
            for (int i = 0; i < body.OriginalPoints.Length; i++)
            {
                body.OriginalPoints[i].Position = BLAS.Add(body.RelativePointsPositionToCenterOfMass[i], body.CenterOfMassCartesian);
            }
        }

        /// <summary>
        /// Computes the body vector for a given object.
        /// The LoS vector is inverted as if the vector emerges from the 
        /// object to the camera.
        /// A counter-clockwise rotation matrix (R) in 2D coordinates (x-y) is 
        /// created, discarding the Z component of LoS.
        /// The final body vector is computed by simple rotation transform:
        /// R * losVector.
        /// 
        /// A proper check for the aspect angle can be computed by:
        /// aspect_angle = cos^(-1) (dot(-losVector, bodyVector) / (||losVector|| * ||bodyVector||)).
        /// </summary>
        /// <param name="body">Body to compute body vector for.</param>
        private void ComputeBodyVector(Body body)
        {
            // Rotation matrix around Z axis, assuming projection of LoS vector on x-y plane.
            // Can be only a 2D rotation for simplicity.
            // Anyway, Z axis component is discarded since R[2, 2] is 0.
            double[,] R_z = Rotations.CreateRotationMatrixZ(Rotations.ToRadians(body.AspectAngle));

            for (int i = 0; i < 3; i++)
            {
                R_z[2, i] = 0.0;
            }

            // Perform rotation. Axis of rotation is CoM.
            // Take the minus of LoS vector as if it points from CoM to camera.
            // This way a rotation followed by translation of the vector to CoM
            // results in the required body vector and its direction.
            //body.BodyVector = BLAS.Multiply(R_z, new double[] { -camera.LineOfSightCartesian[0], -camera.LineOfSightCartesian[1], -camera.LineOfSightCartesian[2] });
            body.BodyVector = BLAS.Multiply(R_z, new double[] { -m_CameraLOS[0], -m_CameraLOS[1], -m_CameraLOS[2] });
            BLAS.Normalize(body.BodyVector);
        }

        /// <summary>
        /// Rotate body points around CoM and Z axis using yaw (aspect) angle.
        /// </summary>
        /// <param name="body">Body to apply yaw rotation transform.</param>
        private void TransformBodyPointsByYaw(Body body)
        {
            // Rotation matrix around Z axis.
            // Again, operations can be simplified if using only 2D rotation.
            double[,] R_z = Rotations.CreateRotationMatrixZ(Rotations.ToRadians(body.AspectAngle));

            // Rotate points around CoM by updating relative position.
            for (int i = 0; i < body.OriginalPoints.Length; i++)
            {
                // Apply rotation transformation to relative position.
                body.RelativePointsPositionToCenterOfMass[i] = BLAS.Multiply(R_z, body.RelativePointsPositionToCenterOfMass[i]);
            }

            // Recompute body points using CoM.
            UpdatePointsPositionWithCenterOfMass(body);
        }

        /// <summary>
        /// Rotates the object points around the body vector using roll angle.
        /// </summary>
        /// <param name="body">Body to apply roll rotation transform.</param>
        private void TransformBodyPointsByRoll(Body body)
        {
            // The body vector defines the rotation axis. It is already 
            // normalized following body vector computation.
            double[] u = body.BodyVector;

            // Create rotation matrix around body vector.
            double[,] R_general = Rotations.CreateRotationMatrixGeneric(u, Rotations.ToRadians(body.RollAngle));

            // Rotate points around CoM by updating relative position.
            for (int i = 0; i < body.OriginalPoints.Length; i++)
            {
                // Apply rotation transformation to relative position.
                body.RelativePointsPositionToCenterOfMass[i] = BLAS.Multiply(R_general, body.RelativePointsPositionToCenterOfMass[i]);
            }

            // Recompute body points using CoM.
            UpdatePointsPositionWithCenterOfMass(body);
        }

        /// <summary>
        /// Rotates the object points around the LoS vector using rotate angle.
        /// NOTE: This can be eliminated by rotating the camera projection axes.
        /// </summary>
        /// <param name="body">Body to apply LoS rotation transform.</param>
        private void TransformBodyPointsByRotate(Body body)
        {
            // The body vector defines the rotation axis. It is already 
            // normalized following body vector computation.
            //double[] u = camera.LineOfSightCartesian;
            double[] u = m_CameraLOS;

            // Create rotation matrix around LoS vector.
            double[,] R_general = Rotations.CreateRotationMatrixGeneric(u, Rotations.ToRadians(body.RotateAngle));

            // Rotate points around CoM by updating relative position.
            for (int i = 0; i < body.OriginalPoints.Length; i++)
            {
                // Apply rotation transformation to relative position.
                body.RelativePointsPositionToCenterOfMass[i] = BLAS.Multiply(R_general, body.RelativePointsPositionToCenterOfMass[i]);
            }

            // Recompute body points using CoM.
            UpdatePointsPositionWithCenterOfMass(body);
        }

        
        /// <summary>
        /// Copies center-of-mass and points position from given arrays to 
        /// body instance.
        /// </summary>
        /// <param name="body">Body instance to copy center-of-mass and points position into.</param>
        /// <param name="copyOfCoM">Array to copy body center-of-mass from.</param>
        /// <param name="copyOfPoints">List to copy body points position from.</param>
        public void RestoreOriginalCenterOfMassAndPointsPosition(Body body, double[] copyOfCoM, List<double[]> copyOfPoints)
        {
            if (copyOfCoM != null && copyOfPoints != null)
            {
                // Copy CoM from given array into body.
                Array.Copy(copyOfCoM, body.CenterOfMassCartesian, copyOfCoM.Length);

                // Copy points from given list into body.
                for (int i = 0; i < body.OriginalPoints.Length; i++)
                {
                    Array.Copy(copyOfPoints[i], body.OriginalPoints[i].Position, copyOfPoints[i].Length);
                }
            }
        }

       
    }
}
